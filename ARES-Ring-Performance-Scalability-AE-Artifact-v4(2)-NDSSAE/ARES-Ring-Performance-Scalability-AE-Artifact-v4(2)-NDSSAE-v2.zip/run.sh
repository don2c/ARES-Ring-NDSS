#!/usr/bin/env bash
set -euo pipefail
python3 --version
if [[ -f requirements.txt ]]; then
  pip install -r requirements.txt
else
  pip install -r requirements-min.txt
fi
# This package shares the same runner name; it regenerates the performance CSVs and LaTeX tables.
python3 src/run_ogts_compliance.py
