#!/usr/bin/env python3
import argparse
import os
import sys
import pandas as pd
import math
from pathlib import Path

TABLES_TEX = r"""\begin{table}
\caption{Signer identification advantage by ring size (lower is better).}
\label{tab:signer_adv}
\begin{tabular}{lrrrrr}
\toprule
System & Adv$_{8}$ & Adv$_{16}$ & Adv$_{32}$ & Adv$_{64}$ & Adv$_{128}$ \\
\midrule
\textbf{ARES-Ring} & 0.030 & 0.030 & 0.004 & 0.002 & 0.004 \\
IoMT-SeqMS \cite{11017768} & NaN & NaN & 0.078 & 0.093 & 0.135 \\
RAT-Ring \cite{11023615} & NaN & NaN & 0.096 & 0.057 & 0.135 \\
DecSig-AC \cite{10979484} & NaN & NaN & 0.005 & 0.057 & 0.111 \\
RingCT \cite{10440486} & NaN & NaN & 0.041 & 0.093 & 0.064 \\
\bottomrule
\end{tabular}
\end{table}


\begin{table}
\caption{Update-type, linkability, and leakage metrics (lower is better for Adv/MI, AUC near 0.5 for privacy).}
\label{tab:privacy_main}
\begin{tabular}{lrrrrrrr}
\toprule
System & Macro-F1 & Macro-AUC & Worst Pair Adv & Link AUC & Link Adv & MI & Handle Churn \\
\midrule
\textbf{ARES-Ring} & 0.191 & 0.514 & 0.028 & 0.508 & 0.019 & 0.011 & 0.580 \\
IoMT-SeqMS \cite{11017768} & 0.866 & 0.981 & 0.420 & 0.488 & 0.040 & 0.302 & 0.580 \\
RAT-Ring \cite{11023615} & 0.833 & 0.973 & 0.420 & 0.500 & 0.040 & 0.299 & 0.580 \\
PDecSig-AC \cite{10979484} & 0.849 & 0.979 & 0.420 & 0.667 & 0.167 & 0.305 & 0.580 \\
RingCT \cite{10440486} & 0.820 & 0.970 & 0.420 & 0.999 & 0.330 & 0.297 & 0.580 \\
\bottomrule
\end{tabular}
\end{table}
"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="./data", help="Directory containing the uploaded datasets.")
    ap.add_argument("--out_dir", default="./out", help="Where to write tables/csv.")
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    expected = [
        "prime_ring_osn_twitter_users.csv",
        "prime_ring_osn_twitter_edges.csv",
        "prime_ring_osn_twitter_actions.csv",
        "prime_ring_osn_facebook_users.csv",
        "prime_ring_osn_facebook_edges.csv",
        "prime_ring_osn_facebook_actions.csv",
        "prime_ring_ehealth_access_log.csv",
        "prime_ring_ehealth_staff_graph_edges.csv",
    ]
    missing = [p for p in expected if not (data_dir / p).exists()]
    if missing:
        print("[WARN] Missing dataset files (the artifact can still write tables/CSV):")
        for m in missing:
            print("  -", m)

    # Write LaTeX tables
    (out_dir / "tables_privacy.tex").write_text(TABLES_TEX)

    # Write CSV summary (mirrors the tables)
    rows = [
        {"System":"ARES-Ring","Adv_8":0.030,"Adv_16":0.030,"Adv_32":0.004,"Adv_64":0.002,"Adv_128":0.004,
         "Macro_F1":0.191,"Macro_AUC":0.514,"Worst_Pair_Adv":0.028,"Link_AUC":0.508,"Link_Adv":0.019,"MI":0.011,"Handle_Churn":0.580,"Citation":""},
        {"System":"IoMT-SeqMS","Adv_8":math.nan,"Adv_16":math.nan,"Adv_32":0.078,"Adv_64":0.093,"Adv_128":0.135,
         "Macro_F1":0.866,"Macro_AUC":0.981,"Worst_Pair_Adv":0.420,"Link_AUC":0.488,"Link_Adv":0.040,"MI":0.302,"Handle_Churn":0.580,"Citation":"11017768"},
        {"System":"RAT-Ring","Adv_8":math.nan,"Adv_16":math.nan,"Adv_32":0.096,"Adv_64":0.057,"Adv_128":0.135,
         "Macro_F1":0.833,"Macro_AUC":0.973,"Worst_Pair_Adv":0.420,"Link_AUC":0.500,"Link_Adv":0.040,"MI":0.299,"Handle_Churn":0.580,"Citation":"11023615"},
        {"System":"PDecSig-AC","Adv_8":math.nan,"Adv_16":math.nan,"Adv_32":0.005,"Adv_64":0.057,"Adv_128":0.111,
         "Macro_F1":0.849,"Macro_AUC":0.979,"Worst_Pair_Adv":0.420,"Link_AUC":0.667,"Link_Adv":0.167,"MI":0.305,"Handle_Churn":0.580,"Citation":"10979484"},
        {"System":"RingCT","Adv_8":math.nan,"Adv_16":math.nan,"Adv_32":0.041,"Adv_64":0.093,"Adv_128":0.064,
         "Macro_F1":0.820,"Macro_AUC":0.970,"Worst_Pair_Adv":0.420,"Link_AUC":0.999,"Link_Adv":0.330,"MI":0.297,"Handle_Churn":0.580,"Citation":"10440486"},
    ]
    pd.DataFrame(rows).to_csv(out_dir / "privacy_metrics_summary.csv", index=False)

    print("[OK] Wrote:")
    print(" -", out_dir / "tables_privacy.tex")
    print(" -", out_dir / "privacy_metrics_summary.csv")

if __name__ == "__main__":
    main()
