#!/usr/bin/env bash
set -euo pipefail
python3 --version
if [[ -f requirements.txt ]]; then
  pip install -r requirements.txt
else
  pip install -r requirements-min.txt
fi
python3 run_metrics.py
