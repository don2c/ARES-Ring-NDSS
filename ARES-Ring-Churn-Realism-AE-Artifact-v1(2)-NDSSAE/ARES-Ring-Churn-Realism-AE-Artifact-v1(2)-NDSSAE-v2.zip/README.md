# ARES-Ring NDSS Artifact (module: Dataset-grounded churn realism metrics)

## Scope
This package reproduces the **Dataset-grounded churn realism metrics** results reported in the ARES-Ring paper (NDSS submission).
It contains scripts, derived CSV outputs, and LaTeX tables used in the manuscript.

## Environment
- Python 3.10+ (tested on Ubuntu 22.04)
- Recommended: `python -m venv .venv && source .venv/bin/activate`
- Install: `pip install -r requirements.txt` (if present) or `pip install -r requirements-min.txt`

## Quick start
```bash
python3 run_metrics.py
```

## Outputs (expected files)
- `churn_intensity_metrics.csv`
- `constraint_change_mix.csv`
- `burstiness_metrics.csv`
- `results_tables.tex`

## Determinism and randomness
Where randomized procedures are used (bootstrap, sampling, LLM proposal filtering), the scripts fix a seed and log it into `results/metadata.json` (or console output).

## Data and ethics
The included datasets are public OSN graph traces and de-identified clinical event logs. No raw identifiers are shipped. The artifact contains only the derived tables used by the paper.


## Reproduction contract
Running the commands above must regenerate the `.tex` tables with the same row/column structure and values (within floating-point print tolerance).

