# ARES-Ring AE Artifact (Correctness and safety under churn)

This package reproduces the evaluation for **1) Correctness and safety under churn** across:
- OSN-Twitter workload
- OSN-Facebook workload
- E-Health access-log workload

## What it generates
The script produces CSV outputs and a LaTeX table file:

- `results/summary_correctness_safety_under_churn.csv`
- `results/update_validity_by_type.csv`
- `results/failure_modes.csv`
- `results/tables_correctness_safety_under_churn.tex`

The LaTeX file contains Tables:
- `tab:churn_correctness_summary`
- `tab:update_validity_by_type`
- `tab:failure_modes`

## Requirements
- Python 3.9+
- `pandas`, `numpy`

Install:
```bash
pip install -r requirements.txt
```

## Run
From the artifact root:
```bash
python3 scripts/run_churn_eval.py
```

## Data included
All CSV datasets are under `data/`, including the **E-Health** logs:
- `prime_ring_ehealth_access_log.csv`
- `prime_ring_ehealth_staff_graph_edges.csv`

## Notes on the prototype
The script models the **OGTS one-gate** contract with:
- fixed envelope checks (byte/time budgets),
- `UpdValid` enforced inside the proof predicate,
- replay rejection via status freshness,
- rollback rejection via stale consent handle (modeled as proof failure).

The script uses a fixed random seed for deterministic outputs.
