#!/usr/bin/env bash
set -euo pipefail
python3 --version
if [[ -f requirements.txt ]]; then
  pip install -r requirements.txt
else
  pip install -r requirements-min.txt
fi
# Generates LaTeX tables from the provided CSVs
python3 -c "import pandas as pd; print('CSV files present:', [p for p in ['llm_apr.csv','coverage_and_worstcase.csv','worstcase_uplift.csv','must_have_metrics.csv'] if __import__('os').path.exists(p)])"
