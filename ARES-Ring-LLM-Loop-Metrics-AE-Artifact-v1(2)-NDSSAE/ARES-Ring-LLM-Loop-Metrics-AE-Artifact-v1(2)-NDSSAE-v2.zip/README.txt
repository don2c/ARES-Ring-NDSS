ARES-Ring AE Artifact: Section 6 (LLM stress-case loop metrics) + minimal must-have set

Files
- llm_apr.csv
- coverage_and_worstcase.csv
- worstcase_uplift.csv
- must_have_metrics.csv
- tables_llm_and_musthave.tex

Dataset grounding
- Loaded datasets: prime_ring_ehealth_access_log.csv, prime_ring_osn_twitter_actions.csv, prime_ring_osn_facebook_actions.csv
- Workload scale used: 100000 records/events

Method notes
- LLM is proposer-only.
- Deterministic checker enforces admissibility.
- LLM runtime is excluded from protocol timing.
